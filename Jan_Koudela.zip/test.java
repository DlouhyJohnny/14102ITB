import java.util.Scanner;
public class test {
    public static Scanner sc = new Scanner(System.in);
    public static int[] pole;
    public static void main(String[] args) {
        Napln();
        Vypis();
        Porovnani();
    }
    public static void Napln() {
        System.out.println("Zadejte velikost: ");
        pole = new int[sc.nextInt()];

        for (int i = 0; i < pole.length; i++) {
            System.out.println("Zadavate "+(i+1)+" cislo: ");
            pole[i] = sc.nextInt();
        }
    }
    public static void Vypis() {
        System.out.println("Vase pole obsahuje: ");
        for (int i = 0; i < pole.length; i++) {
            System.out.print(pole[i]);
        }
    }
    public static void Porovnani() {
        int misto = (pole.length/2);
        if (pole[misto] % 2 != 0) {
            pole[misto] = 0;
        } else {
            
        }
    }
    
}
